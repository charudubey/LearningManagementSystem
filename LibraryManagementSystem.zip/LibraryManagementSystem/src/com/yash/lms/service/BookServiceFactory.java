package com.yash.lms.service;

import com.yash.lms.vo.Book;

public class BookServiceFactory{

	public BookService getBook(Book input) {
		
		if(input.getBookCategory().equalsIgnoreCase("HORROR"))
			return new HorrorBook();
		else if(input.getBookCategory().equalsIgnoreCase("SUSPENSE"))
			return new SuspenseBook();
		
		return null;
	}

	
}

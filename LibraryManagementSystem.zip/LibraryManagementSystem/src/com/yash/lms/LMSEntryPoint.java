package com.yash.lms;

import java.util.List;
import java.util.Optional;
import java.util.Scanner;

import com.yash.lms.service.BookService;
import com.yash.lms.service.BookServiceFactory;
import com.yash.lms.service.BookServiceImpl;
import com.yash.lms.vo.Book;

public class LMSEntryPoint {

	public static void main(String[] args) {
		
		Book book = new Book();
		Scanner getInput = new Scanner(System.in);
		System.out.println("Please enter category: ");
		book.setBookCategory(getInput.next());

		try{
			BookServiceFactory bookServiceFactory = new BookServiceFactory();
			BookService service = bookServiceFactory.getBook(book);
			Optional<BookService> serviceCheckNull = Optional.ofNullable(service);
			if(!serviceCheckNull.isPresent()){
				System.out.println("Invalid Category!");
			} else{
				List<Book> output = service.searchBook(book);
				checkNull(output);
			}
			
			System.out.println("Please Enter Book ID: ");
			book = new Book();
			book.setBookId(getInput.nextInt());
			BookService bookService = new BookServiceImpl();
			List<Book> output = bookService.searchBook(book);
			checkNull(output);
			
		} catch(Exception e){
			e.printStackTrace();
		} finally{
			getInput.close();
		}

	}
	
	private static void checkNull(List<Book> output){
		Optional<List<Book>> outputCheckNull = Optional.ofNullable(output);
		if(outputCheckNull.isPresent())
			output.forEach(System.out::println);
 		else
			System.out.println("Book Not found!");
	}

}
